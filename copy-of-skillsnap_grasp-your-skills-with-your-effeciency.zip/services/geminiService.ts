
import { GoogleGenAI, Type } from "@google/genai";
import { House, Skill, SkillRequest } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getSortingDecision = async (answers: string[]): Promise<{ house: House; reasoning: string }> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Based on these user responses: ${answers.join(". ")}, assign the user to one of these four learning focus tracks: 
    - Gryffindor (for Leadership, Initiative & Bold Action)
    - Slytherin (for Strategy, Ambition & Goal Orientation)
    - Ravenclaw (for Analysis, Creativity & Knowledge Pursuit)
    - Hufflepuff (for Collaboration, Dedication & Consistency). 
    Explain the reasoning based on professional and personal development psychology.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          house: { type: Type.STRING, enum: ['Gryffindor', 'Slytherin', 'Ravenclaw', 'Hufflepuff'] },
          reasoning: { type: Type.STRING }
        },
        required: ["house", "reasoning"]
      }
    }
  });

  return JSON.parse(response.text);
};

export const generateSkillPath = async (interests: string, house: House): Promise<Skill[]> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Generate 4 structured learning modules for a student in the ${house} track interested in ${interests}. 
    Provide a clear descriptive name for the module and the industry-standard 'originalName'. 
    Difficulty should be 'Easy', 'Medium', or 'Hard'. 
    Classify each as either "Academic" (technical/professional/career) or "Personal" (hobbies/soft skills/wellness). 
    IMPORTANT: For modules classified as "Academic", you MUST also provide an "academicSubCategory" field which must be either "Technical" (hands-on skills like coding, building, labs) or "Theoretical" (concepts, history, philosophy, logic).
    Return as an array of objects.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            name: { type: Type.STRING },
            originalName: { type: Type.STRING },
            category: { type: Type.STRING },
            description: { type: Type.STRING },
            level: { type: Type.NUMBER },
            experience: { type: Type.NUMBER },
            maxExperience: { type: Type.NUMBER },
            difficulty: { type: Type.STRING, enum: ['Easy', 'Medium', 'Hard'] },
            type: { type: Type.STRING, enum: ['Academic', 'Personal'] },
            academicSubCategory: { type: Type.STRING, enum: ['Technical', 'Theoretical'] }
          },
          required: ["id", "name", "originalName", "category", "description", "level", "experience", "maxExperience", "difficulty", "type"]
        }
      }
    }
  });

  return JSON.parse(response.text);
};

export const classifySkillRequest = async (description: string): Promise<Partial<SkillRequest>> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `A user wants to learn this: "${description}". 
    1. Classify it as "Academic" (career/technical/academic) or "Personal" (hobby/lifestyle/wellness).
    2. Suggest a professional "Module Name".
    3. Provide a one-sentence "Reasoning" for why it fits this classification.
    4. Provide a brief "Impact Analysis" of how this skill contributes to their development.
    Return as a JSON object with 'type', 'aiSkillName', 'reasoning', and 'analysis'.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          type: { type: Type.STRING, enum: ["Academic", "Personal"] },
          aiSkillName: { type: Type.STRING },
          reasoning: { type: Type.STRING },
          analysis: { type: Type.STRING }
        },
        required: ["type", "aiSkillName", "reasoning", "analysis"]
      }
    }
  });

  return JSON.parse(response.text);
};

export const getProfessorResponse = async (history: {role: string, content: string}[], userPrompt: string, professorName: string) => {
  // Format history for Gemini API
  const formattedHistory = history.map(msg => ({
    role: msg.role === 'user' ? 'user' : 'model',
    parts: [{ text: msg.content }]
  }));

  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      systemInstruction: `You are Senior Mentor ${professorName}. You are helping a student on the SkillSnap learning platform. Use clear, encouraging, and instructional language. Focus on practical advice for "Academic Mastery" (Career/Education) or "Personal Enrichment" (Life/Wellness). Avoid overly mystical jargon; favor professional mentorship.`,
      history: formattedHistory
    }
  });

  return chat.sendMessageStream({ message: userPrompt });
};
