
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { House, UserProfile, Skill, Difficulty, Trainer, SkillRequest } from './types';
import { getSortingDecision, generateSkillPath, getProfessorResponse, classifySkillRequest } from './services/geminiService';
import MagicCard from './components/MagicCard';
import ProgressBar from './components/ProgressBar';
import Modal from './components/Modal';
import { 
  Sparkles, 
  Book, 
  User, 
  MessageCircle, 
  Zap, 
  LayoutGrid, 
  Mail, 
  ArrowRight, 
  ArrowLeft,
  X, 
  Star, 
  Filter,
  Info,
  PlusCircle,
  Clock,
  Briefcase,
  Smile,
  Search,
  Trophy,
  BrainCircuit,
  Music,
  Utensils,
  Camera,
  Leaf,
  Wind,
  Mic2,
  Dumbbell,
  Palette,
  Send,
  GraduationCap,
  Crown,
  Code2,
  Database,
  Globe,
  Lock,
  History,
  ChevronRight,
  Target,
  BarChart3,
  Cpu,
  BookOpen,
  Trash2,
  Binary,
  Layers,
  CheckCircle2,
  Settings2,
  Medal,
  Heart,
  MessageSquare
} from 'lucide-react';

const DifficultyBadge: React.FC<{ difficulty: Difficulty }> = ({ difficulty }) => {
  const styles = {
    'Easy': 'border-emerald-900/50 text-emerald-500 bg-emerald-900/10',
    'Medium': 'border-amber-900/50 text-amber-500 bg-amber-900/10',
    'Hard': 'border-rose-900/50 text-rose-500 bg-rose-900/10'
  };

  return (
    <span className={`text-[10px] px-2 py-0.5 rounded border font-magic uppercase tracking-wider ${styles[difficulty]}`}>
      {difficulty}
    </span>
  );
};

const trainerData: Record<string, Trainer> = {
  'Minerva': {
    name: 'Lead Mentor Minerva',
    role: 'Technical Excellence Lead',
    bio: 'Minerva specializes in technical rigor and software architecture. She guides students through the complexities of coding and system logic.',
    image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&q=80&w=400&h=400',
    specialty: 'Computer Science & Software Logic'
  },
  'Filius': {
    name: 'Lead Mentor Filius',
    role: 'Aesthetic Arts Director',
    bio: 'Filius focuses on the harmony of expression. He mentors students in the delicate arts of music, rhythm, and visual aesthetics.',
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400&h=400',
    specialty: 'Music, Performance & Visual Arts'
  },
  'Pomona': {
    name: 'Lead Mentor Pomona',
    role: 'Practical Wellness Advisor',
    bio: 'Pomona teaches the grounding arts of wellness, nutrition, and environmental care. She believes in growth that is both sustainable and nourishing.',
    image: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?auto=format&fit=crop&q=80&w=400&h=400',
    specialty: 'Health, Culinary Arts & Wellness'
  },
  'Sybill': {
    name: 'Lead Mentor Sybill',
    role: 'Strategic Insight Advisor',
    bio: 'Sybill focuses on the patterns of human behavior and strategic foresight. She guides students in leadership and critical soft skills.',
    image: 'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&q=80&w=400&h=400',
    specialty: 'Strategy, Leadership & Soft Skills'
  },
  'Albus': {
    name: 'Head Mentor Albus',
    role: 'Academy Director',
    bio: 'Albus oversees the intersection of all disciplines, ensuring that students develop wisdom alongside their technical skills.',
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=400&h=400',
    specialty: 'Universal Mastery & Wisdom'
  }
};

const libraryCategories = ['All Skills', 'Academic Skills', 'Personal Skills'];

const libraryCourses = [
  // Academic Sector
  { title: "Web Development", originalName: "Modern Frontend Stack", category: "Academic Skills", difficulty: "Medium" as Difficulty, duration: "15 Hours", type: 'Academic', icon: <Globe className="w-4 h-4" /> },
  { title: "Python Coding", originalName: "Core Software Logic", category: "Academic Skills", difficulty: "Easy" as Difficulty, duration: "8 Hours", type: 'Academic', icon: <Code2 className="w-4 h-4" /> },
  { title: "SQL & Data", originalName: "Database Management Systems", category: "Academic Skills", difficulty: "Hard" as Difficulty, duration: "12 Hours", type: 'Academic', icon: <Database className="w-4 h-4" /> },
  { title: "Artificial Intelligence", originalName: "Neural Networks & ML", category: "Academic Skills", difficulty: "Hard" as Difficulty, duration: "20 Hours", type: 'Academic', icon: <BrainCircuit className="w-4 h-4" /> },
  
  // Personal Sector
  { title: "Piano & Music", originalName: "Rhythmic Foundations", category: "Personal Skills", difficulty: "Medium" as Difficulty, duration: "10 Hours", type: 'Personal', icon: <Music className="w-4 h-4" /> },
  { title: "Culinary Arts", originalName: "Kitchen Fundamentals", category: "Personal Skills", difficulty: "Easy" as Difficulty, duration: "5 Hours", type: 'Personal', icon: <Utensils className="w-4 h-4" /> },
  { title: "Dance & Choreography", originalName: "Physical Expression", category: "Personal Skills", difficulty: "Medium" as Difficulty, duration: "8 Hours", type: 'Personal', icon: <Wind className="w-4 h-4" /> },
  { title: "Oil Painting", originalName: "Visual Arts & Color", category: "Personal Skills", difficulty: "Easy" as Difficulty, duration: "6 Hours", type: 'Personal', icon: <Palette className="w-4 h-4" /> },
  { title: "Digital Photography", originalName: "Light & Composition", category: "Personal Skills", difficulty: "Easy" as Difficulty, duration: "4 Hours", type: 'Personal', icon: <Camera className="w-4 h-4" /> },
];

type AppView = 'landing' | 'register' | 'sorting' | 'onboarding_sector' | 'first_request' | 'first_analysis' | 'generated_path' | 'dashboard' | 'my_academic_spells' | 'my_spells' | 'mentor' | 'library' | 'request' | 'history';

const App: React.FC = () => {
  const [view, setView] = useState<AppView>('landing');
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeProfessor, setActiveProfessor] = useState('Minerva');
  const [chatHistories, setChatHistories] = useState<Record<string, { role: string; content: string }[]>>({
    'Minerva': [],
    'Filius': [],
    'Pomona': [],
    'Sybill': [],
    'Albus': []
  });
  const [userInput, setUserInput] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  // UI States
  const [isLoginView, setIsLoginView] = useState(false);
  const [regForm, setRegForm] = useState({ name: '', email: '', password: '' });
  const [sortingStep, setSortingStep] = useState(0);
  const [sortingAnswers, setSortingAnswers] = useState<string[]>([]);
  const [selectedTrainer, setSelectedTrainer] = useState<Trainer | null>(null);
  const [isTrainerModalOpen, setIsTrainerModalOpen] = useState(false);
  const [skillRequestDesc, setSkillRequestDesc] = useState('');
  const [selectedLibraryCategory, setSelectedLibraryCategory] = useState<string>('All Skills');
  const [searchTerm, setSearchTerm] = useState('');
  const [mySkillsSort, setMySkillsSort] = useState<'name' | 'level' | 'difficulty'>('name');
  const [currentAnalysis, setCurrentAnalysis] = useState<Partial<SkillRequest> | null>(null);
  const [selectedArchiveRequest, setSelectedArchiveRequest] = useState<SkillRequest | null>(null);
  const [onboardingSkills, setOnboardingSkills] = useState<Skill[]>([]);
  const [requestStep, setRequestStep] = useState<'sector_selection' | 'description_entry'>('sector_selection');
  const [chosenSector, setChosenSector] = useState<'Academic' | 'Personal' | null>(null);

  // Manual Module State
  const [isManualModuleOpen, setIsManualModuleOpen] = useState(false);
  const [manualModule, setManualModule] = useState({
    name: '',
    description: '',
    difficulty: 'Medium' as Difficulty,
    sector: 'Academic' as 'Academic' | 'Personal',
    subCategory: 'Technical' as any,
    mentor: 'Minerva'
  });

  const viewOrder: AppView[] = [
    'landing', 'register', 'sorting', 'onboarding_sector', 'first_request', 'first_analysis', 'generated_path',
    'dashboard', 'my_academic_spells', 'my_spells', 'request', 'mentor', 'history', 'library'
  ];

  useEffect(() => {
    const savedUser = localStorage.getItem('skillsnap_user');
    if (savedUser) {
      try {
        const parsed = JSON.parse(savedUser);
        setUser(parsed);
      } catch (e) {
        console.error("Failed to parse user profile", e);
      }
    }

    const savedChats = localStorage.getItem('skillsnap_chats');
    if (savedChats) {
      try {
        setChatHistories(JSON.parse(savedChats));
      } catch (e) {
        console.error("Failed to parse chat histories", e);
      }
    }
  }, []);

  useEffect(() => {
    if (user) {
      localStorage.setItem('skillsnap_user', JSON.stringify(user));
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('skillsnap_chats', JSON.stringify(chatHistories));
  }, [chatHistories]);

  useEffect(() => {
    if (view === 'mentor') {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [chatHistories, view, activeProfessor]);

  const handleNextView = () => {
    const currentIndex = viewOrder.indexOf(view);
    if (currentIndex < viewOrder.length - 1) setView(viewOrder[currentIndex + 1]);
    else setView(viewOrder[0]);
  };

  const handlePrevView = () => {
    const currentIndex = viewOrder.indexOf(view);
    if (currentIndex > 0) setView(viewOrder[currentIndex - 1]);
    else setView(viewOrder[viewOrder.length - 1]);
  };

  const tracks = {
    [House.Gryffindor]: { color: '#991b1b', bg: 'bg-red-900/20', border: 'border-red-900', text: 'text-red-500', label: 'Leadership Track' },
    [House.Slytherin]: { color: '#166534', bg: 'bg-emerald-900/20', border: 'border-emerald-900', text: 'text-emerald-500', label: 'Strategic Track' },
    [House.Ravenclaw]: { color: '#1e40af', bg: 'bg-blue-900/20', border: 'border-blue-900', text: 'text-blue-500', label: 'Analytical Track' },
    [House.Hufflepuff]: { color: '#854d0e', bg: 'bg-yellow-900/20', border: 'border-yellow-900', text: 'text-yellow-500', label: 'Collaborative Track' },
  };

  const getRelevantTrainer = (skillData: any): Trainer => {
    const name = (skillData.name || skillData.title || skillData.originalName || '').toLowerCase();
    const category = (skillData.category || '').toLowerCase();
    const type = (skillData.type || '').toLowerCase();

    if (name.includes('code') || name.includes('dev') || name.includes('sql') || name.includes('python') || name.includes('ai') || name.includes('software') || name.includes('logic')) {
      return trainerData['Minerva'];
    }
    if (name.includes('music') || name.includes('piano') || name.includes('dance') || name.includes('paint') || name.includes('art') || name.includes('photo') || name.includes('design') || name.includes('composition')) {
      return trainerData['Filius'];
    }
    if (name.includes('cook') || name.includes('culinary') || name.includes('wellness') || name.includes('mind') || name.includes('health') || name.includes('nutrition') || name.includes('nature') || name.includes('kitchen') || name.includes('swim') || name.includes('sport') || name.includes('gym')) {
      return trainerData['Pomona'];
    }
    if (name.includes('lead') || name.includes('manage') || name.includes('strategy') || name.includes('social') || name.includes('comm') || name.includes('foresight') || name.includes('leadership')) {
      return trainerData['Sybill'];
    }
    if (type === 'academic' || category === 'academic skills') return trainerData['Minerva'];
    if (type === 'personal' || category === 'personal skills') return trainerData['Filius'];
    return trainerData['Albus'];
  };

  const handleOpenTrainerForSkill = (skillData: any) => {
    const trainer = getRelevantTrainer(skillData);
    setSelectedTrainer(trainer);
    setIsTrainerModalOpen(true);
  };

  const handleAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLoginView) {
      const savedUser = localStorage.getItem('skillsnap_user');
      if (savedUser) {
        const parsed = JSON.parse(savedUser);
        if (parsed.email === regForm.email && parsed.password === regForm.password) {
          setUser(parsed);
          setView('dashboard');
        } else {
          alert("Invalid email or password.");
        }
      } else {
        alert("No user found. Please register.");
        setIsLoginView(false);
      }
    } else {
      if (regForm.name && regForm.email && regForm.password) {
        const newUser: UserProfile = {
          name: regForm.name,
          email: regForm.email,
          password: regForm.password,
          house: null,
          level: 1,
          xp: 0,
          housePoints: 0,
          skills: [],
          interests: [],
          requests: []
        };
        setUser(newUser);
        setView('sorting');
      }
    }
  };

  const handleSort = async (answers: string[]) => {
    setLoading(true);
    try {
      const decision = await getSortingDecision(answers);
      setUser(prev => prev ? { ...prev, house: decision.house } : null);
      // After sorting, choose sector
      setView('onboarding_sector');
    } catch (error) {
      console.error("Assessment failed", error);
    } finally {
      setLoading(false);
    }
  };

  const analyzeInitialSkill = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!skillRequestDesc.trim()) return;
    setLoading(true);
    try {
      const prompt = chosenSector ? `I definitely want to learn something in the ${chosenSector} sector. Specifically: ${skillRequestDesc}` : skillRequestDesc;
      const classification = await classifySkillRequest(prompt);
      setCurrentAnalysis(classification);
      
      if (view === 'first_request') {
        setView('first_analysis');
      }
    } catch (error) {
      console.error("Analysis failed", error);
    } finally {
      setLoading(false);
    }
  };

  const approveSkillRequest = async () => {
    if (!currentAnalysis || !user) return;
    setLoading(true);
    try {
      const newSkills = await generateSkillPath(skillRequestDesc, user.house || House.Hufflepuff);
      const newRequest: SkillRequest = {
        id: Math.random().toString(36).substr(2, 9),
        originalDescription: skillRequestDesc,
        aiSkillName: currentAnalysis.aiSkillName || "Module",
        type: currentAnalysis.type as 'Academic' | 'Personal',
        status: 'Approved',
        requestDate: new Date().toLocaleDateString(),
        reasoning: currentAnalysis.reasoning,
        analysis: currentAnalysis.analysis
      };
      
      setUser(prev => {
        if (!prev) return null;
        return {
          ...prev,
          requests: [newRequest, ...(prev.requests || [])],
          skills: [...newSkills, ...prev.skills],
          housePoints: prev.housePoints + 50
        };
      });

      if (view === 'first_analysis') {
        setOnboardingSkills(newSkills);
        setView('generated_path');
      } else {
        const nextView = currentAnalysis.type === 'Academic' ? 'my_academic_spells' : 'my_spells';
        setSkillRequestDesc('');
        setCurrentAnalysis(null);
        setChosenSector(null);
        setRequestStep('sector_selection');
        setView(nextView);
      }
    } catch (error) {
      console.error("Approval failed", error);
    } finally {
      setLoading(false);
    }
  };

  const openManualModuleRegistration = (sector: 'Academic' | 'Personal', subCategory: any) => {
    let defaultMentor = 'Albus';
    if (sector === 'Academic') {
      defaultMentor = subCategory === 'Technical' ? 'Minerva' : 'Albus';
    } else {
      defaultMentor = subCategory === 'Life Skills' ? 'Filius' : 'Pomona';
    }

    setManualModule({ 
      sector,
      subCategory, 
      mentor: defaultMentor,
      name: '',
      description: '',
      difficulty: 'Medium'
    });
    setIsManualModuleOpen(true);
  };

  const handleAddManualModule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const newSkill: Skill = {
      id: Math.random().toString(36).substr(2, 9),
      name: `Core: ${manualModule.name}`,
      originalName: manualModule.name,
      level: 1,
      experience: 0,
      maxExperience: 100,
      category: `${manualModule.sector} Mastery`,
      description: manualModule.description,
      difficulty: manualModule.difficulty,
      type: manualModule.sector,
      academicSubCategory: manualModule.sector === 'Academic' ? manualModule.subCategory : undefined,
      personalSubCategory: manualModule.sector === 'Personal' ? manualModule.subCategory : undefined
    };

    setUser(prev => prev ? {
      ...prev,
      skills: [newSkill, ...prev.skills],
      housePoints: prev.housePoints + 20
    } : null);

    setIsManualModuleOpen(false);
  };

  const handleChat = async () => {
    if (!userInput.trim()) return;
    const currentHist = chatHistories[activeProfessor] || [];
    const newMessage = { role: 'user', content: userInput };
    
    // Add user message to state
    setChatHistories(prev => ({
      ...prev,
      [activeProfessor]: [...prev[activeProfessor], newMessage]
    }));
    
    const contextHistory = [...currentHist, newMessage];
    setUserInput('');
    setLoading(true);
    
    try {
      const stream = await getProfessorResponse(contextHistory, userInput, activeProfessor);
      let fullText = "";
      
      // Initialize model message
      setChatHistories(prev => ({
        ...prev,
        [activeProfessor]: [...prev[activeProfessor], { role: 'model', content: "" }]
      }));

      for await (const chunk of stream) {
        fullText += chunk.text || '';
        setChatHistories(prev => {
          const updated = [...prev[activeProfessor]];
          updated[updated.length - 1].content = fullText;
          return { ...prev, [activeProfessor]: updated };
        });
      }
    } catch (error) {
      console.error("Chat failed", error);
    } finally {
      setLoading(false);
    }
  };

  const clearChat = () => {
    if (window.confirm(`Are you sure you want to clear your conversation with Mentor ${activeProfessor}?`)) {
      setChatHistories(prev => ({
        ...prev,
        [activeProfessor]: []
      }));
    }
  };

  const logout = () => {
    if (window.confirm("Are you sure you want to log out?")) {
      setUser(null);
      setView('landing');
      setRegForm({ name: '', email: '', password: '' });
    }
  };

  const getSortedSkills = (skills: Skill[]) => {
    return [...skills].sort((a, b) => {
      if (mySkillsSort === 'name') return a.originalName.localeCompare(b.originalName);
      if (mySkillsSort === 'level') return b.level - a.level;
      return 0;
    });
  };

  const calculateSectorProgress = (type: 'Academic' | 'Personal') => {
    const sectorSkills = user?.skills.filter(s => s.type === type) || [];
    if (sectorSkills.length === 0) return 0;
    const totalExp = sectorSkills.reduce((acc, s) => acc + (s.experience / s.maxExperience), 0);
    return Math.round((totalExp / sectorSkills.length) * 100);
  };

  const calculateSubSectorProgress = (type: 'Academic' | 'Personal', subType: string) => {
    const sectorSkills = user?.skills.filter(s => {
      if (type === 'Academic') {
        return s.type === 'Academic' && (subType === 'Theoretical' ? (s.academicSubCategory === 'Theoretical' || !s.academicSubCategory) : s.academicSubCategory === subType);
      } else {
        return s.type === 'Personal' && (subType === 'Life Skills' ? (s.personalSubCategory === 'Life Skills' || !s.personalSubCategory) : s.personalSubCategory === subType);
      }
    }) || [];
    if (sectorSkills.length === 0) return 0;
    const totalExp = sectorSkills.reduce((acc, s) => acc + (s.experience / s.maxExperience), 0);
    return Math.round((totalExp / sectorSkills.length) * 100);
  };

  const SectorSelection = ({ onSelect, activeSector }: { onSelect: (s: 'Academic' | 'Personal') => void, activeSector?: string | null }) => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <MagicCard 
        glowColor="#60a5fa" 
        className={`cursor-pointer group border-blue-900/30 hover:border-blue-400 transition-all ${activeSector === 'Academic' ? 'border-blue-400 scale-[1.02]' : ''}`}
        onClick={() => onSelect('Academic')}
      >
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="p-5 bg-blue-500/10 rounded-2xl text-blue-400 group-hover:scale-110 transition-transform">
            <Briefcase className="w-12 h-12" />
          </div>
          <h4 className="text-2xl font-magic text-blue-400">Academic Mastery</h4>
          <p className="text-sm text-stone-400 leading-relaxed">Coding, Engineering, Data Analysis, Professional Strategy, and Career Advancement.</p>
          <button className="px-6 py-2 bg-blue-400 text-stone-900 rounded-full font-magic text-xs shadow-[0_0_15px_rgba(96,165,250,0.3)]">Enter Sector</button>
        </div>
      </MagicCard>

      <MagicCard 
        glowColor="#f472b6" 
        className={`cursor-pointer group border-pink-900/30 hover:border-pink-400 transition-all ${activeSector === 'Personal' ? 'border-pink-400 scale-[1.02]' : ''}`}
        onClick={() => onSelect('Personal')}
      >
        <div className="flex flex-col items-center text-center space-y-4">
          <div className="p-5 bg-pink-500/10 rounded-2xl text-pink-400 group-hover:scale-110 transition-transform">
            <Smile className="w-12 h-12" />
          </div>
          <h4 className="text-2xl font-magic text-pink-400">Personal Enrichment</h4>
          <p className="text-sm text-stone-400 leading-relaxed">Music, Arts, Wellness, Hobbies, Lifestyle, and Creative Expression.</p>
          <button className="px-6 py-2 bg-pink-400 text-stone-900 rounded-full font-magic text-xs shadow-[0_0_15px_rgba(244,114,182,0.3)]">Enter Sector</button>
        </div>
      </MagicCard>
    </div>
  );

  const SkillCard = ({ skill, index }: { skill: Skill, index: number }) => {
    const randomTrainer = useMemo(() => {
      const trainers = Object.values(trainerData);
      return trainers[index % trainers.length];
    }, [index]);

    const getIcon = () => {
      if (skill.type === 'Academic') {
        return skill.academicSubCategory === 'Technical' ? <Cpu className="w-4 h-4" /> : <BookOpen className="w-4 h-4" />;
      } else {
        return skill.personalSubCategory === 'Sports' ? <Dumbbell className="w-4 h-4" /> : <Smile className="w-4 h-4" />;
      }
    };

    const getGlow = () => {
      if (skill.type === 'Academic') return skill.academicSubCategory === 'Technical' ? '#60a5fa' : '#818cf8';
      return skill.personalSubCategory === 'Sports' ? '#fbbf24' : '#f472b6';
    };

    return (
      <MagicCard className={`animate-in slide-in-from-bottom duration-500 ${skill.type === 'Academic' ? 'border-blue-900/30' : 'border-pink-900/30'}`}>
        <div className="flex justify-between items-start mb-2">
          <div className={`p-1.5 rounded-lg text-white`} style={{ backgroundColor: `${getGlow()}20`, color: getGlow() }}>
            {getIcon()}
          </div>
          <DifficultyBadge difficulty={skill.difficulty} />
        </div>
        <h4 className="font-sans font-bold text-white mb-1 line-clamp-1">{skill.name}</h4>
        <p className="text-[9px] text-stone-500 uppercase tracking-widest mb-3">
          {skill.type} {skill.academicSubCategory ? `• ${skill.academicSubCategory}` : ''} {skill.personalSubCategory ? `• ${skill.personalSubCategory}` : ''}
        </p>
        <div className="text-[10px] text-stone-400 italic line-clamp-3 mb-4 min-h-[40px]">"{skill.description}"</div>
        <ProgressBar current={skill.experience} max={skill.maxExperience} color={getGlow()} />
        
        {/* Mentor Attribution */}
        <div className="mt-4 pt-4 border-t border-stone-800 flex items-center gap-3">
          <img src={randomTrainer.image} className="w-7 h-7 rounded-full border border-stone-700 object-cover" alt="" />
          <div className="text-[9px]">
            <p className="text-stone-500 uppercase tracking-tighter">Lead Mentor</p>
            <p className="text-[#d6bc7e] font-magic">{randomTrainer.name.replace('Lead Mentor ', '')}</p>
          </div>
        </div>
      </MagicCard>
    );
  };

  const NavigationFooter = () => (
    <div className="flex justify-center gap-6 mt-12 py-8 border-t border-stone-800">
      <button 
        onClick={handlePrevView} 
        className="px-8 py-3 rounded-full border border-stone-800 text-stone-500 hover:text-[#d6bc7e] transition-all bg-stone-900/50 font-magic text-sm flex items-center gap-3 shadow-lg"
      >
        <ArrowLeft className="w-5 h-5" /> Previous
      </button>
      <button 
        onClick={handleNextView} 
        className="px-8 py-3 rounded-full border border-stone-800 text-stone-500 hover:text-[#d6bc7e] transition-all bg-stone-900/50 font-magic text-sm flex items-center gap-3 shadow-lg"
      >
        Next <ArrowRight className="w-5 h-5" />
      </button>
    </div>
  );

  if (view === 'landing') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-4 bg-[url('https://images.unsplash.com/photo-1510133769068-08198f1d95d7?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center">
        <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
        <div className="relative z-10 text-center max-w-2xl px-6">
          <Sparkles className="w-20 h-20 text-[#d6bc7e] mx-auto mb-8 animate-pulse" />
          <h1 className="text-5xl md:text-7xl font-magic text-[#d6bc7e] mb-6 drop-shadow-lg leading-tight">SkillSnap</h1>
          <p className="text-xl md:text-2xl text-stone-300 mb-12 italic">Precision skill development with dedicated Academic and Personal sectors.</p>
          <div className="space-y-8">
            <button onClick={() => setView('register')} className="px-12 py-5 bg-[#d6bc7e] text-[#0c0a09] font-magic text-2xl rounded-full hover:scale-105 transition-transform shadow-[0_0_30px_#d6bc7e50]">Access Academy <ArrowRight className="inline-block ml-3 w-6 h-6" /></button>
          </div>
          <NavigationFooter />
        </div>
      </div>
    );
  }

  if (view === 'register') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0c0a09] p-4">
        <div className="w-full max-w-md space-y-6">
          <MagicCard title={isLoginView ? "Academy Login" : "Academy Enrollment"}>
            <form onSubmit={handleAuth} className="space-y-6">
              {!isLoginView && (
                <div className="space-y-2 animate-in slide-in-from-top-2 duration-300">
                  <label className="text-xs uppercase tracking-widest text-[#d6bc7e] font-magic">Full Name</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-500" />
                    <input required value={regForm.name} onChange={e => setRegForm({...regForm, name: e.target.value})} className="w-full bg-stone-900/50 border border-stone-800 rounded-lg py-3 pl-10 pr-4 outline-none focus:border-[#d6bc7e] text-stone-200" placeholder="Your Name" />
                  </div>
                </div>
              )}
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-[#d6bc7e] font-magic">Email Address</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-500" />
                  <input required type="email" value={regForm.email} onChange={e => setRegForm({...regForm, email: e.target.value})} className="w-full bg-stone-900/50 border border-stone-800 rounded-lg py-3 pl-10 pr-4 outline-none focus:border-[#d6bc7e] text-stone-200" placeholder="email@example.com" />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-widest text-[#d6bc7e] font-magic">Security Key (Password)</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-500" />
                  <input required type="password" value={regForm.password} onChange={e => setRegForm({...regForm, password: e.target.value})} className="w-full bg-stone-900/50 border border-stone-800 rounded-lg py-3 pl-10 pr-4 outline-none focus:border-[#d6bc7e] text-stone-200" placeholder="••••••••" />
                </div>
              </div>
              <button type="submit" className="w-full py-4 bg-[#d6bc7e] text-[#0c0a09] font-magic rounded-lg hover:brightness-110 transition-all shadow-lg">
                {isLoginView ? 'Verify Identity' : 'Secure Enrollment'}
              </button>
              <div className="text-center">
                <button type="button" onClick={() => setIsLoginView(!isLoginView)} className="text-xs text-stone-500 hover:text-[#d6bc7e] transition-colors underline decoration-stone-800 underline-offset-4">
                  {isLoginView ? "Don't have an account? Register" : "Already registered? Login"}
                </button>
              </div>
            </form>
          </MagicCard>
          <NavigationFooter />
        </div>
      </div>
    );
  }

  if (view === 'sorting') {
    const questions = ["What is your primary goal for professional growth?", "How do you prefer to approach new challenges?", "What area of development do you value most?", "What is your desired outcome from this platform?"];
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0c0a09] p-4">
        <div className="w-full max-w-xl space-y-6">
          <MagicCard className="text-center" title="Learning Track Assessment">
            {loading ? (
              <div className="py-20 animate-pulse"><Sparkles className="w-12 h-12 text-[#d6bc7e] mx-auto mb-4" /><p className="text-[#d6bc7e] font-magic text-2xl">Analyzing Focus Group...</p></div>
            ) : (
              <div className="space-y-6">
                <p className="text-stone-300 italic mb-8">"{questions[sortingStep]}"</p>
                <div className="grid gap-3">
                  {['Leading & Motivating Others', 'Analyzing Complex Data', 'Building Consistent Systems', 'Strategizing For Results'].map((ans, i) => (
                    <button key={ans} onClick={() => { const nextAnswers = [...sortingAnswers, ans]; if (sortingStep < questions.length - 1) { setSortingAnswers(nextAnswers); setSortingStep(sortingStep + 1); } else { handleSort(nextAnswers); } }} className="w-full p-4 border border-stone-800 rounded-lg hover:bg-stone-800 hover:border-[#d6bc7e] transition-all text-left">{ans}</button>
                  ))}
                </div>
                <div className="flex justify-center gap-2 pt-6">{questions.map((_, i) => (<div key={i} className={`h-1.5 w-8 rounded-full ${i <= sortingStep ? 'bg-[#d6bc7e]' : 'bg-stone-800'}`} />))}</div>
              </div>
            )}
          </MagicCard>
          <NavigationFooter />
        </div>
      </div>
    );
  }

  if (view === 'onboarding_sector') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0c0a09] p-4">
        <div className="w-full max-w-4xl space-y-8">
          <div className="text-center space-y-2">
            <h3 className="text-4xl font-magic text-[#d6bc7e]">Choose Your Path</h3>
            <p className="text-stone-500 italic">Select the primary sector for your first mastery</p>
          </div>
          <SectorSelection onSelect={(s) => { setChosenSector(s); setView('first_request'); }} />
          <NavigationFooter />
        </div>
      </div>
    );
  }

  if (view === 'first_request') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0c0a09] p-4">
        <div className="w-full max-w-2xl space-y-6">
          <MagicCard 
            title={`${chosenSector} Intake Assessment`} 
            glowColor={chosenSector === 'Academic' ? '#60a5fa' : '#f472b6'}
          >
            <div className="flex items-start gap-4 mb-8">
              <div className={`p-3 rounded-full border ${chosenSector === 'Academic' ? 'bg-blue-500/10 border-blue-900/30 text-blue-400' : 'bg-pink-500/10 border-pink-900/30 text-pink-400'}`}>
                {chosenSector === 'Academic' ? <BrainCircuit className="w-6 h-6" /> : <Palette className="w-6 h-6" />}
              </div>
              <div>
                <h4 className="text-lg font-magic text-stone-200">First Mastery Requirement</h4>
                <p className="text-sm text-stone-500 italic">"Describe the specific {chosenSector?.toLowerCase()} skill you wish to pursue. Our AI will craft your path."</p>
              </div>
            </div>
            <form onSubmit={analyzeInitialSkill} className="space-y-6">
              <div className="space-y-2">
                <label className={`text-xs uppercase tracking-widest font-magic ${chosenSector === 'Academic' ? 'text-blue-400' : 'text-pink-400'}`}>
                  Mastery Objective & Description
                </label>
                <textarea 
                  required 
                  value={skillRequestDesc} 
                  onChange={(e) => setSkillRequestDesc(e.target.value)} 
                  placeholder={`e.g. ${chosenSector === 'Academic' ? 'I want to master React.js to build modern web applications...' : 'I want to learn culinary arts to cook healthy meals for my family...'}`} 
                  className="w-full min-h-[150px] bg-stone-900/50 border border-stone-800 rounded-xl p-6 text-sm outline-none transition-all resize-none text-stone-300 shadow-inner focus:border-[#d6bc7e]" 
                />
              </div>
              <button 
                type="submit" 
                disabled={loading || !skillRequestDesc.trim()} 
                className={`w-full py-4 font-magic rounded-xl hover:scale-105 transition-all disabled:opacity-50 ${chosenSector === 'Academic' ? 'bg-blue-400 text-stone-900' : 'bg-pink-400 text-stone-900'}`}
              >
                {loading ? 'Consulting the Archives...' : 'Generate Sector Impact Report'}
              </button>
            </form>
          </MagicCard>
          <NavigationFooter />
        </div>
      </div>
    );
  }

  if (view === 'first_analysis') {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0c0a09] p-4">
        <div className="w-full max-w-3xl space-y-6">
          <MagicCard title="Academy Classification Report" glowColor={currentAnalysis?.type === 'Academic' ? '#60a5fa' : '#f472b6'}>
            {loading ? (
              <div className="py-20 text-center animate-pulse">
                <Sparkles className="w-12 h-12 text-[#d6bc7e] mx-auto mb-4" />
                <p className="text-[#d6bc7e] font-magic">Formulating Your Path...</p>
              </div>
            ) : currentAnalysis && (
              <div className="py-2 space-y-8 animate-in zoom-in-95 duration-500">
                <div className="flex flex-col md:flex-row items-center gap-8 border-b border-stone-800 pb-8">
                  <div className={`w-24 h-24 rounded-full flex items-center justify-center border-2 ${currentAnalysis.type === 'Academic' ? 'border-blue-500 bg-blue-500/10' : 'border-pink-500 bg-pink-500/10'}`}>
                    {currentAnalysis.type === 'Academic' ? <Briefcase className="w-12 h-12 text-blue-400" /> : <Smile className="w-12 h-12 text-pink-400" />}
                  </div>
                  <div className="text-center md:text-left">
                    <h4 className="text-3xl font-magic text-white mb-1">{currentAnalysis.aiSkillName}</h4>
                    <p className={`text-xs uppercase tracking-[0.2em] font-magic ${currentAnalysis.type === 'Academic' ? 'text-blue-400' : 'text-pink-400'}`}>{currentAnalysis.type} Sector Verified</p>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <h5 className="text-xs uppercase tracking-widest text-stone-500 font-magic flex items-center gap-2"><Info className="w-3 h-3" /> Categorization Insight</h5>
                    <p className="text-sm text-stone-300 italic leading-relaxed bg-stone-900/50 p-4 rounded-lg border border-stone-800">"{currentAnalysis.reasoning}"</p>
                  </div>
                  <div className="space-y-3">
                    <h5 className="text-xs uppercase tracking-widest text-stone-500 font-magic flex items-center gap-2"><Star className="w-3 h-3" /> Development Potential</h5>
                    <p className="text-sm text-stone-300 leading-relaxed bg-stone-900/50 p-4 rounded-lg border border-stone-800">{currentAnalysis.analysis}</p>
                  </div>
                </div>
                <div className="pt-4">
                  <button onClick={approveSkillRequest} disabled={loading} className={`w-full py-4 font-magic rounded-xl hover:brightness-110 transition-all shadow-lg ${currentAnalysis.type === 'Academic' ? 'bg-blue-400 text-stone-900' : 'bg-pink-400 text-stone-900'}`}>
                    Accept and Generate My Path
                  </button>
                </div>
              </div>
            )}
          </MagicCard>
          <NavigationFooter />
        </div>
      </div>
    );
  }

  if (view === 'generated_path') {
    const isAcademic = onboardingSkills.some(s => s.type === 'Academic');
    const technicalSkills = onboardingSkills.filter(s => s.academicSubCategory === 'Technical');
    const theoreticalSkills = onboardingSkills.filter(s => s.academicSubCategory === 'Theoretical' || (s.type === 'Academic' && !s.academicSubCategory));
    const personalSkills = onboardingSkills.filter(s => s.type === 'Personal');

    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#0c0a09] p-4 py-12">
        <div className="w-full max-w-6xl space-y-10">
          <div className="text-center space-y-4">
            <h2 className="text-5xl font-magic text-[#d6bc7e]">Curriculum Synchronized</h2>
            <p className="text-stone-500 italic max-w-2xl mx-auto">Our AI has formulated your initial learning path, balancing specialized expertise with mentor guidance.</p>
          </div>

          <div className="space-y-12">
            {isAcademic ? (
              <>
                {/* Technical Results */}
                <section className="space-y-6">
                  <div className="flex items-center gap-3 border-b border-stone-800 pb-3">
                    <Cpu className="w-6 h-6 text-blue-400" />
                    <h3 className="text-2xl font-magic text-blue-400">Technical Mastery Results</h3>
                    <span className="text-[10px] text-stone-500 uppercase bg-stone-900 px-3 py-1 rounded border border-stone-800 ml-auto tracking-widest">Hands-On Practice</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {technicalSkills.length > 0 ? (
                      technicalSkills.map((skill, i) => (
                        <SkillCard key={skill.id} skill={skill} index={i} />
                      ))
                    ) : (
                      <div className="col-span-full py-12 text-center bg-stone-900/20 border border-dashed border-stone-800 rounded-2xl italic text-stone-600">No specific technical modules identified.</div>
                    )}
                  </div>
                </section>

                {/* Theoretical Results */}
                <section className="space-y-6">
                  <div className="flex items-center gap-3 border-b border-stone-800 pb-3">
                    <BookOpen className="w-6 h-6 text-blue-400" />
                    <h3 className="text-2xl font-magic text-blue-400">Theoretical Foundation Results</h3>
                    <span className="text-[10px] text-stone-500 uppercase bg-stone-900 px-3 py-1 rounded border border-stone-800 ml-auto tracking-widest">Conceptual Wisdom</span>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {theoreticalSkills.map((skill, i) => (
                      <SkillCard key={skill.id} skill={skill} index={i + 10} />
                    ))}
                  </div>
                </section>
              </>
            ) : (
              <section className="space-y-6">
                <div className="flex items-center gap-3 border-b border-stone-800 pb-3">
                  <Smile className="w-6 h-6 text-pink-400" />
                  <h3 className="text-2xl font-magic text-pink-400">Personal Growth Curriculum</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {personalSkills.map((skill, i) => (
                    <SkillCard key={skill.id} skill={skill} index={i} />
                  ))}
                </div>
              </section>
            )}
          </div>

          <div className="text-center space-y-6 pt-12 border-t border-stone-800">
            <p className="text-[#d6bc7e] font-magic text-sm uppercase tracking-widest">Finalize and initialize your primary sector:</p>
            <div className="flex flex-col sm:flex-row justify-center gap-6">
              <button 
                onClick={() => setView('my_academic_spells')} 
                className="px-10 py-5 bg-blue-400 text-stone-900 font-magic text-xl rounded-xl hover:scale-105 transition-transform shadow-[0_0_25px_rgba(96,165,250,0.4)] flex items-center justify-center gap-3"
              >
                <Briefcase className="w-6 h-6" /> Academic Mastery
              </button>
              <button 
                onClick={() => setView('my_spells')} 
                className="px-10 py-5 bg-pink-400 text-stone-900 font-magic text-xl rounded-xl hover:scale-105 transition-transform shadow-[0_0_25px_rgba(244,114,182,0.4)] flex items-center justify-center gap-3"
              >
                <Smile className="w-6 h-6" /> Personal Enrichment
              </button>
            </div>
          </div>
          <NavigationFooter />
        </div>
      </div>
    );
  }

  const currentMentorChat = chatHistories[activeProfessor] || [];

  return (
    <div className="min-h-screen bg-[#0c0a09] text-stone-300">
      <nav className="fixed top-0 left-0 h-screen w-20 bg-[#141211] border-r border-stone-800 hidden md:flex flex-col items-center py-8 gap-8 z-50">
        <div className="text-[#d6bc7e] p-2 hover:bg-stone-800 rounded-xl cursor-pointer" onClick={() => setView('dashboard')}><Crown className="w-8 h-8" /></div>
        <div className={`p-3 rounded-xl cursor-pointer transition-all ${view === 'dashboard' ? 'bg-[#d6bc7e] text-stone-900' : 'text-stone-500'}`} title="Dashboard" onClick={() => setView('dashboard')}><LayoutGrid className="w-6 h-6" /></div>
        <div className={`p-3 rounded-xl cursor-pointer transition-all ${view === 'my_academic_spells' ? 'bg-blue-400 text-stone-900 shadow-[0_0_15px_rgba(96,165,250,0.5)]' : 'text-stone-500'}`} title="Academic Mastery" onClick={() => setView('my_academic_spells')}><Briefcase className="w-6 h-6" /></div>
        <div className={`p-3 rounded-xl cursor-pointer transition-all ${view === 'my_spells' ? 'bg-pink-400 text-stone-900 shadow-[0_0_15px_rgba(244,114,182,0.5)]' : 'text-stone-500'}`} title="Personal Growth" onClick={() => setView('my_spells')}><Smile className="w-6 h-6" /></div>
        <div className={`p-3 rounded-xl cursor-pointer transition-all ${view === 'request' ? 'bg-[#d6bc7e] text-stone-900' : 'text-stone-500'}`} title="Analyze New Skill" onClick={() => { setChosenSector(null); setRequestStep('sector_selection'); setView('request'); }}><PlusCircle className="w-6 h-6" /></div>
        <div className={`p-3 rounded-xl cursor-pointer transition-all ${view === 'history' ? 'bg-[#d6bc7e] text-stone-900' : 'text-stone-500'}`} title="Academy Archives" onClick={() => setView('history')}><History className="w-6 h-6" /></div>
        <div className={`p-3 rounded-xl cursor-pointer transition-all ${view === 'mentor' ? 'bg-[#d6bc7e] text-stone-900' : 'text-stone-500'}`} title="Expert Mentoring" onClick={() => setView('mentor')}><MessageCircle className="w-6 h-6" /></div>
        <div className={`p-3 rounded-xl cursor-pointer transition-all ${view === 'library' ? 'bg-[#d6bc7e] text-stone-900' : 'text-stone-500'}`} title="Skill Library" onClick={() => setView('library')}><Book className="w-6 h-6" /></div>
        <div className="mt-auto pb-4"><button onClick={logout} className="p-3 text-stone-600 hover:text-red-500 transition-colors"><X className="w-6 h-6" /></button></div>
      </nav>

      <main className="md:ml-20 ml-0 p-4 md:p-8 pb-24">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-6">
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-4">
              <button onClick={() => setView('dashboard')} className="p-2 rounded-full border border-stone-800 text-stone-500 hover:text-[#d6bc7e] transition-all bg-stone-900/50"><LayoutGrid className="w-4 h-4" /></button>
              <h2 className="text-3xl md:text-4xl font-magic text-[#d6bc7e]">
                {view === 'dashboard' ? 'Academy Overview' : 
                 view === 'my_academic_spells' ? 'Academic Mastery Sector' : 
                 view === 'my_spells' ? 'Personal Enrichment Sector' : 
                 view === 'request' ? (requestStep === 'sector_selection' ? 'Choose Sector' : 'Intake Assessment') : 
                 view === 'history' ? 'Academy Archives' :
                 view === 'library' ? 'Complete Skill Library' : 
                 view === 'mentor' ? 'Consultation' : 'Academy'}
              </h2>
            </div>
            <p className="text-stone-500 italic text-sm">
              {view === 'my_academic_spells' ? 'Refining your professional and technical prowess.' :
               view === 'my_spells' ? 'Nurturing your creative and physical growth.' :
               `Welcome Student ${user?.name}. Your growth is recorded in the sectors.`}
            </p>
          </div>
          <div className="flex gap-6 items-center">
            <div className="text-right"><p className="text-[10px] uppercase tracking-widest text-stone-500 mb-1">Academy XP</p><p className="text-2xl font-magic text-[#d6bc7e]">{user?.housePoints}</p></div>
            {user?.house && (<div className={`px-4 py-2 rounded-lg border ${tracks[user.house].border} ${tracks[user.house].bg} ${tracks[user.house].text} font-magic`}>{tracks[user.house].label}</div>)}
          </div>
        </header>

        {view === 'dashboard' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-in fade-in duration-500">
            <div className="lg:col-span-2 space-y-12">
              <section>
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center gap-3">
                    <Briefcase className="text-blue-400" />
                    <h3 className="text-xl font-magic text-blue-400">Academic Skills Sector</h3>
                  </div>
                  <button onClick={() => setView('my_academic_spells')} className="text-xs font-magic text-[#d6bc7e] hover:underline">View All Academic</button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {user?.skills.filter(s => s.type === 'Academic').length === 0 ? (
                    <div className="col-span-full p-8 text-center bg-stone-900/50 border border-stone-800 rounded-xl italic text-stone-500">
                      No Academic modules started. Coding, SQL, and Engineering await.
                    </div>
                  ) : (
                    user?.skills.filter(s => s.type === 'Academic').slice(0, 2).map(skill => (
                      <MagicCard key={skill.id} className="cursor-pointer border-blue-900/20 hover:border-blue-400/50" onClick={() => handleOpenTrainerForSkill(skill)}>
                        <div className="flex justify-between items-start mb-2">
                          <div><h4 className="text-lg font-sans font-bold text-white block">{skill.originalName}</h4></div>
                          <span className="text-xs font-magic bg-stone-900 px-2 py-1 rounded border border-stone-800">Lvl {skill.level}</span>
                        </div>
                        <ProgressBar current={skill.experience} max={skill.maxExperience} color={skill.academicSubCategory === 'Technical' ? "#60a5fa" : "#818cf8"} />
                      </MagicCard>
                    ))
                  )}
                </div>
              </section>

              <section>
                <div className="flex justify-between items-center mb-6">
                  <div className="flex items-center gap-3">
                    <Smile className="text-pink-400" />
                    <h3 className="text-xl font-magic text-pink-400">Personal Skills Sector</h3>
                  </div>
                  <button onClick={() => setView('my_spells')} className="text-xs font-magic text-[#d6bc7e] hover:underline">View All Personal</button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {user?.skills.filter(s => s.type === 'Personal').length === 0 ? (
                    <div className="col-span-full p-8 text-center bg-stone-900/50 border border-stone-800 rounded-xl italic text-stone-500">
                      No Personal modules started. Music, Cooking, and Art await.
                    </div>
                  ) : (
                    user?.skills.filter(s => s.type === 'Personal').slice(0, 2).map(skill => (
                      <MagicCard key={skill.id} className="cursor-pointer border-pink-900/20 hover:border-pink-400/50" onClick={() => handleOpenTrainerForSkill(skill)}>
                        <div className="flex justify-between items-start mb-2">
                          <div><h4 className="text-lg font-sans font-bold text-white block">{skill.originalName}</h4></div>
                          <span className="text-xs font-magic bg-stone-900 px-2 py-1 rounded border border-stone-800">Lvl {skill.level}</span>
                        </div>
                        <ProgressBar current={skill.experience} max={skill.maxExperience} color="#f472b6" />
                      </MagicCard>
                    ))
                  )}
                </div>
              </section>

              <section>
                <div className="flex items-center gap-3 mb-6">
                  <Trophy className="text-[#d6bc7e]" />
                  <h3 className="text-xl font-magic">Daily Academy Objectives</h3>
                </div>
                <div className="space-y-4">
                  <div onClick={() => setView('my_academic_spells')} className="flex items-center gap-4 p-5 bg-stone-900/50 rounded-xl border border-stone-800 hover:border-blue-400 transition-all cursor-pointer group">
                    <div className="w-12 h-12 rounded-full bg-stone-800 flex items-center justify-center group-hover:bg-blue-400 group-hover:text-stone-900 transition-colors"><Code2 className="w-6 h-6" /></div>
                    <div className="flex-1"><h4 className="text-lg font-magic group-hover:text-blue-400">Academic Task</h4><p className="text-xs text-stone-500">Master coding or data logic today.</p></div>
                    <p className="text-sm text-blue-400">+25 XP</p>
                  </div>
                  <div onClick={() => setView('my_spells')} className="flex items-center gap-4 p-5 bg-stone-900/50 rounded-xl border border-stone-800 hover:border-pink-400 transition-all cursor-pointer group">
                    <div className="w-12 h-12 rounded-full bg-stone-800 flex items-center justify-center group-hover:bg-pink-400 group-hover:text-stone-900 transition-colors"><Palette className="w-6 h-6" /></div>
                    <div className="flex-1"><h4 className="text-lg font-magic group-hover:text-pink-400">Personal Goal</h4><p className="text-xs text-stone-500">Practice your creative or lifestyle skills.</p></div>
                    <p className="text-sm text-pink-400">+25 XP</p>
                  </div>
                </div>
              </section>
            </div>
            
            <aside className="space-y-8">
              <MagicCard title="Student Metrics">
                <div className="space-y-4">
                  <p className="text-xs text-stone-500">Class Batch Status:</p>
                  <div className="flex -space-x-3 mb-4">{[1,2,3,4].map(i => (<div key={i} className="w-10 h-10 rounded-full bg-stone-700 border-2 border-[#1c1917]" />))}<div className="w-10 h-10 rounded-full bg-[#d6bc7e] border-2 border-[#1c1917] flex items-center justify-center text-xs font-magic text-stone-900">+12</div></div>
                  <div className="pt-4 border-t border-stone-800">
                    <p className="text-[10px] text-stone-500 uppercase tracking-widest mb-1">Sector Balance Score</p>
                    <ProgressBar current={85} max={100} color="#d6bc7e" />
                  </div>
                  <button onClick={() => setView('history')} className="w-full py-2 bg-stone-900 border border-stone-800 rounded-lg text-xs font-magic hover:text-[#d6bc7e] transition-all flex items-center justify-center gap-2 mt-4"><History className="w-3 h-3" /> View Past Reports</button>
                </div>
              </MagicCard>
            </aside>
          </div>
        )}

        {view === 'history' && (
          <div className="space-y-8 animate-in fade-in duration-500 max-w-5xl mx-auto">
            <div className="flex flex-col md:flex-row gap-8">
              <div className="flex-1 space-y-6">
                <div className="flex items-center gap-3 border-b border-stone-800 pb-4"><History className="text-[#d6bc7e] w-6 h-6" /><h3 className="text-xl font-magic text-[#d6bc7e]">Previous Skill Reports</h3></div>
                {user?.requests.length === 0 ? (
                  <div className="p-12 text-center bg-stone-900/30 border border-dashed border-stone-800 rounded-2xl italic text-stone-600">No previous reports found in the archives.</div>
                ) : (
                  <div className="space-y-4">
                    {user?.requests.map(req => (
                      <MagicCard key={req.id} className="cursor-pointer hover:border-[#d6bc7e] transition-all group" onClick={() => setSelectedArchiveRequest(req)}>
                        <div className="flex justify-between items-start">
                          <div className="flex items-center gap-4">
                            <div className={`p-2 rounded-lg ${req.type === 'Academic' ? 'bg-blue-500/10 text-blue-400' : 'bg-pink-500/10 text-pink-400'}`}>
                              {req.type === 'Academic' ? <Briefcase className="w-5 h-5" /> : <Smile className="w-5 h-5" />}
                            </div>
                            <div>
                              <h4 className="font-sans font-bold text-white text-lg">{req.aiSkillName}</h4>
                              <p className="text-xs text-stone-500 italic mt-0.5">Analyzed on {req.requestDate}</p>
                            </div>
                          </div>
                          <ChevronRight className="w-5 h-5 text-stone-700 group-hover:text-[#d6bc7e] transition-all" />
                        </div>
                      </MagicCard>
                    ))}
                  </div>
                )}
              </div>

              <div className="w-full md:w-80 space-y-6">
                <div className="flex items-center gap-3 border-b border-stone-800 pb-4"><MessageCircle className="text-[#d6bc7e] w-6 h-6" /><h3 className="text-xl font-magic text-[#d6bc7e]">Recent Chats</h3></div>
                <div className="space-y-3">
                  {Object.entries(chatHistories).filter(([_, hist]) => hist.length > 0).map(([prof, hist]) => (
                    <button key={prof} onClick={() => { setActiveProfessor(prof); setView('mentor'); }} className="w-full p-4 bg-stone-900/50 border border-stone-800 rounded-xl text-left hover:border-[#d6bc7e] transition-all group">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-xs font-magic text-[#d6bc7e]">Mentor {prof}</span>
                        <span className="text-[10px] text-stone-600">{hist.length} messages</span>
                      </div>
                      <p className="text-xs text-stone-400 truncate italic">"{hist[hist.length - 1].content.slice(0, 50)}..."</p>
                    </button>
                  ))}
                  {Object.values(chatHistories).every(h => h.length === 0) && (
                    <div className="p-8 text-center bg-stone-900/20 border border-stone-800 rounded-xl italic text-stone-700 text-xs">No active conversations found.</div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {view === 'my_academic_spells' && (
          <div className="space-y-8 animate-in fade-in duration-500 max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              <div className="lg:col-span-1 space-y-6">
                <div className="bg-blue-900/10 p-6 rounded-2xl border border-blue-900/30">
                  <div className="p-4 bg-blue-400 rounded-xl text-stone-900 shadow-[0_0_20px_rgba(96,165,250,0.4)] w-fit mb-4">
                    <Briefcase className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-magic text-blue-400 mb-2">Academic Mastery</h3>
                  <p className="text-xs text-stone-400 italic leading-relaxed">Your professional growth path, structured into Technical and Theoretical modules.</p>
                </div>

                <MagicCard title="Sector Analytics" glowColor="#60a5fa">
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between text-[10px] uppercase tracking-widest text-stone-500 mb-1">
                        Technical Progress <span>{calculateSubSectorProgress('Academic', 'Technical')}%</span>
                      </div>
                      <ProgressBar current={calculateSubSectorProgress('Academic', 'Technical')} max={100} color="#60a5fa" />
                    </div>
                    <div>
                      <div className="flex justify-between text-[10px] uppercase tracking-widest text-stone-500 mb-1">
                        Theoretical Progress <span>{calculateSubSectorProgress('Academic', 'Theoretical')}%</span>
                      </div>
                      <ProgressBar current={calculateSubSectorProgress('Academic', 'Theoretical')} max={100} color="#818cf8" />
                    </div>
                    <div className="pt-4 border-t border-stone-800">
                      <p className="text-[10px] text-stone-500 uppercase tracking-widest mb-2">Sector Lead Mentor</p>
                      <button onClick={() => {setActiveProfessor('Minerva'); setView('mentor');}} className="w-full flex items-center gap-3 p-2 bg-stone-900 rounded-lg border border-stone-800 hover:border-blue-400 transition-all text-left">
                        <img src={trainerData['Minerva'].image} className="w-8 h-8 rounded-full border border-stone-700" alt="" />
                        <div><p className="text-xs font-magic text-white">Prof. Minerva</p><p className="text-[10px] text-stone-500">Academic Oversight</p></div>
                      </button>
                    </div>
                  </div>
                </MagicCard>
              </div>

              <div className="lg:col-span-3 space-y-10">
                {/* Manual Creation Shortcuts */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div 
                    onClick={() => openManualModuleRegistration('Academic', 'Technical')}
                    className="p-6 bg-blue-900/5 border border-blue-900/20 rounded-2xl hover:border-blue-400 transition-all cursor-pointer group flex items-center gap-4"
                  >
                    <div className="p-3 bg-blue-500/10 rounded-xl text-blue-400 group-hover:scale-110 transition-transform">
                      <PlusCircle className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-lg font-magic text-blue-400 leading-tight">Add Technical Module</h4>
                      <p className="text-[10px] text-stone-500 uppercase">Input manual technical objectives</p>
                    </div>
                  </div>
                  <div 
                    onClick={() => openManualModuleRegistration('Academic', 'Theoretical')}
                    className="p-6 bg-indigo-900/5 border border-indigo-900/20 rounded-2xl hover:border-indigo-400 transition-all cursor-pointer group flex items-center gap-4"
                  >
                    <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-400 group-hover:scale-110 transition-transform">
                      <PlusCircle className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-lg font-magic text-indigo-400 leading-tight">Add Theoretical Module</h4>
                      <p className="text-[10px] text-stone-500 uppercase">Input manual conceptual objectives</p>
                    </div>
                  </div>
                </div>

                {/* Module 1: Technical Mastery */}
                <MagicCard className="bg-[#141211] border-blue-900/30 overflow-visible" glowColor="#60a5fa">
                  <div className="flex items-center justify-between mb-6 pb-4 border-b border-stone-800">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-blue-500/10 rounded-xl text-blue-400">
                        <Binary className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-magic text-blue-400 leading-none mb-1">Technical Skills Module</h3>
                        <p className="text-[10px] text-stone-500 uppercase tracking-[0.2em]">Active Implementation & Lab Work</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-stone-500 uppercase font-magic">
                      <span className="w-2 h-2 rounded-full bg-blue-400"></span> Technical
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {user?.skills.filter(s => s.type === 'Academic' && s.academicSubCategory === 'Technical').length === 0 ? (
                      <div className="col-span-full py-12 text-center bg-stone-900/20 border border-dashed border-stone-800 rounded-xl">
                        <Cpu className="w-8 h-8 text-stone-700 mx-auto mb-2" />
                        <p className="text-stone-600 italic text-sm">No technical modules registered.</p>
                      </div>
                    ) : (
                      getSortedSkills(user?.skills.filter(s => s.type === 'Academic' && s.academicSubCategory === 'Technical') || []).map(skill => (
                        <MagicCard key={skill.id} className="group cursor-pointer border-stone-800 hover:border-pink-400/50 bg-stone-900/40" onClick={() => handleOpenTrainerForSkill(skill)}>
                          <div className="flex justify-between items-start mb-4">
                            <h4 className="text-lg font-sans font-bold text-white block leading-tight">{skill.originalName}</h4>
                            <DifficultyBadge difficulty={skill.difficulty} />
                          </div>
                          <ProgressBar current={skill.experience} max={skill.maxExperience} color="#60a5fa" />
                          <div className="mt-4 flex justify-between items-center text-[9px] text-stone-500 uppercase">
                            <span>Lvl {skill.level} Proficiency</span>
                            <span className="text-blue-400">Technical</span>
                          </div>
                        </MagicCard>
                      ))
                    )}
                  </div>
                </MagicCard>

                {/* Module 2: Theoretical Foundations */}
                <MagicCard className="bg-[#141211] border-indigo-900/30 overflow-visible" glowColor="#818cf8">
                  <div className="flex items-center justify-between mb-6 pb-4 border-b border-stone-800">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-indigo-500/10 rounded-xl text-indigo-400">
                        <Layers className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-magic text-indigo-400 leading-none mb-1">Theoretical Skills Module</h3>
                        <p className="text-[10px] text-stone-500 uppercase tracking-[0.2em]">Concepts, Architecture & First Principles</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-stone-500 uppercase font-magic">
                      <span className="w-2 h-2 rounded-full bg-indigo-400"></span> Theoretical
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {user?.skills.filter(s => s.type === 'Academic' && (s.academicSubCategory === 'Theoretical' || !s.academicSubCategory)).length === 0 ? (
                      <div className="col-span-full py-12 text-center bg-stone-900/20 border border-dashed border-stone-800 rounded-xl">
                        <BookOpen className="w-8 h-8 text-stone-700 mx-auto mb-2" />
                        <p className="text-stone-600 italic text-sm">No theoretical foundations discovered yet.</p>
                      </div>
                    ) : (
                      getSortedSkills(user?.skills.filter(s => s.type === 'Academic' && (s.academicSubCategory === 'Theoretical' || !s.academicSubCategory)) || []).map(skill => (
                        <MagicCard key={skill.id} className="group cursor-pointer border-stone-800 hover:border-indigo-400/50 bg-stone-900/40" onClick={() => handleOpenTrainerForSkill(skill)}>
                          <div className="flex justify-between items-start mb-4">
                            <h4 className="text-lg font-sans font-bold text-white block leading-tight">{skill.originalName}</h4>
                            <DifficultyBadge difficulty={skill.difficulty} />
                          </div>
                          <ProgressBar current={skill.experience} max={skill.maxExperience} color="#818cf8" />
                          <div className="mt-4 flex justify-between items-center text-[9px] text-stone-500 uppercase">
                            <span>Lvl {skill.level} Insight</span>
                            <span className="text-indigo-400">Theory</span>
                          </div>
                        </MagicCard>
                      ))
                    )}
                  </div>
                </MagicCard>

                <div className="pt-6 flex justify-center">
                  <button onClick={() => { setChosenSector('Academic'); setRequestStep('description_entry'); setView('request'); }} className="px-10 py-5 bg-stone-900 border-2 border-stone-800 text-stone-400 hover:border-[#d6bc7e] hover:text-[#d6bc7e] transition-all font-magic rounded-full flex items-center gap-4 text-base shadow-2xl">
                    <BrainCircuit className="w-6 h-6" /> Deep AI Analysis of New Skill
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {view === 'my_spells' && (
          <div className="space-y-8 animate-in fade-in duration-500 max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
              <div className="lg:col-span-1 space-y-6">
                <div className="bg-pink-900/10 p-6 rounded-2xl border border-pink-900/30">
                  <div className="p-4 bg-pink-400 rounded-xl text-stone-900 shadow-[0_0_20px_rgba(244,114,182,0.4)] w-fit mb-4">
                    <Smile className="w-8 h-8" />
                  </div>
                  <h3 className="text-2xl font-magic text-pink-400 mb-2">Personal Enrichment</h3>
                  <p className="text-xs text-stone-400 italic leading-relaxed">Nurturing your creative and physical growth through Life Skills and Sports modules.</p>
                </div>

                <MagicCard title="Growth Analytics" glowColor="#f472b6">
                  <div className="space-y-6">
                    <div>
                      <div className="flex justify-between text-[10px] uppercase tracking-widest text-stone-500 mb-1">
                        Personal Skills Progress <span>{calculateSubSectorProgress('Personal', 'Life Skills')}%</span>
                      </div>
                      <ProgressBar current={calculateSubSectorProgress('Personal', 'Life Skills')} max={100} color="#f472b6" />
                    </div>
                    <div>
                      <div className="flex justify-between text-[10px] uppercase tracking-widest text-stone-500 mb-1">
                        Sports Skills Progress <span>{calculateSubSectorProgress('Personal', 'Sports')}%</span>
                      </div>
                      <ProgressBar current={calculateSubSectorProgress('Personal', 'Sports')} max={100} color="#fbbf24" />
                    </div>
                    <div className="pt-4 border-t border-stone-800">
                      <p className="text-[10px] text-stone-500 uppercase tracking-widest mb-2">Sector Lead Mentor</p>
                      <button onClick={() => {setActiveProfessor('Filius'); setView('mentor');}} className="w-full flex items-center gap-3 p-2 bg-stone-900 rounded-lg border border-stone-800 hover:border-pink-400 transition-all text-left">
                        <img src={trainerData['Filius'].image} className="w-8 h-8 rounded-full border border-stone-700" alt="" />
                        <div><p className="text-xs font-magic text-white">Prof. Filius</p><p className="text-[10px] text-stone-500">Aesthetic Mastery</p></div>
                      </button>
                    </div>
                  </div>
                </MagicCard>
              </div>

              <div className="lg:col-span-3 space-y-10">
                {/* Manual Creation Shortcuts */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div 
                    onClick={() => openManualModuleRegistration('Personal', 'Life Skills')}
                    className="p-6 bg-pink-900/5 border border-pink-900/20 rounded-2xl hover:border-pink-400 transition-all cursor-pointer group flex items-center gap-4"
                  >
                    <div className="p-3 bg-pink-500/10 rounded-xl text-pink-400 group-hover:scale-110 transition-transform">
                      <Heart className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-lg font-magic text-pink-400 leading-tight">Add Personal Mastery Skill</h4>
                      <p className="text-[10px] text-stone-500 uppercase">Communication, Dance, Music, Cooking...</p>
                    </div>
                  </div>
                  <div 
                    onClick={() => openManualModuleRegistration('Personal', 'Sports')}
                    className="p-6 bg-amber-900/5 border border-amber-900/20 rounded-2xl hover:border-amber-400 transition-all cursor-pointer group flex items-center gap-4"
                  >
                    <div className="p-3 bg-amber-500/10 rounded-xl text-amber-400 group-hover:scale-110 transition-transform">
                      <Medal className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-lg font-magic text-amber-400 leading-tight">Add Sports Mastery Module</h4>
                      <p className="text-[10px] text-stone-500 uppercase">Athletics, Gym, Team Sports...</p>
                    </div>
                  </div>
                </div>

                {/* Module 1: Life Skills & Expression */}
                <MagicCard className="bg-[#141211] border-pink-900/30 overflow-visible" glowColor="#f472b6">
                  <div className="flex items-center justify-between mb-6 pb-4 border-b border-stone-800">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-pink-500/10 rounded-xl text-pink-400">
                        <Smile className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-magic text-pink-400 leading-none mb-1">Personal Mastery Module</h3>
                        <p className="text-[10px] text-stone-500 uppercase tracking-[0.2em]">Creativity, Arts & Social Expression</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-stone-500 uppercase font-magic">
                      <span className="w-2 h-2 rounded-full bg-pink-400"></span> Life Skill
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {user?.skills.filter(s => s.type === 'Personal' && (s.personalSubCategory === 'Life Skills' || !s.personalSubCategory)).length === 0 ? (
                      <div className="col-span-full py-12 text-center bg-stone-900/20 border border-dashed border-stone-800 rounded-xl">
                        <MessageSquare className="w-8 h-8 text-stone-700 mx-auto mb-2" />
                        <p className="text-stone-600 italic text-sm">No personal skills registered yet.</p>
                        <button onClick={() => openManualModuleRegistration('Personal', 'Life Skills')} className="mt-4 text-xs font-magic text-pink-400 hover:underline underline-offset-4">Register Communication, Music or Dance</button>
                      </div>
                    ) : (
                      getSortedSkills(user?.skills.filter(s => s.type === 'Personal' && (s.personalSubCategory === 'Life Skills' || !s.personalSubCategory)) || []).map(skill => (
                        <MagicCard key={skill.id} className="group cursor-pointer border-stone-800 hover:border-pink-400/50 bg-stone-900/40" onClick={() => handleOpenTrainerForSkill(skill)}>
                          <div className="flex justify-between items-start mb-4">
                            <h4 className="text-lg font-sans font-bold text-white block leading-tight">{skill.originalName}</h4>
                            <DifficultyBadge difficulty={skill.difficulty} />
                          </div>
                          <ProgressBar current={skill.experience} max={skill.maxExperience} color="#f472b6" />
                          <div className="mt-4 flex justify-between items-center text-[9px] text-stone-500 uppercase">
                            <span>Lvl {skill.level} Harmony</span>
                            <span className="text-pink-400">Personal Module</span>
                          </div>
                        </MagicCard>
                      ))
                    )}
                  </div>
                </MagicCard>

                {/* Module 2: Sports & Athleticism */}
                <MagicCard className="bg-[#141211] border-amber-900/30 overflow-visible" glowColor="#fbbf24">
                  <div className="flex items-center justify-between mb-6 pb-4 border-b border-stone-800">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-amber-500/10 rounded-xl text-amber-400">
                        <Dumbbell className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-magic text-amber-400 leading-none mb-1">Sports Skills Module</h3>
                        <p className="text-[10px] text-stone-500 uppercase tracking-[0.2em]">Physical Prowess & Discipline</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-stone-500 uppercase font-magic">
                      <span className="w-2 h-2 rounded-full bg-amber-400"></span> Physical
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {user?.skills.filter(s => s.type === 'Personal' && s.personalSubCategory === 'Sports').length === 0 ? (
                      <div className="col-span-full py-12 text-center bg-stone-900/20 border border-dashed border-stone-800 rounded-xl">
                        <Medal className="w-8 h-8 text-stone-700 mx-auto mb-2" />
                        <p className="text-stone-600 italic text-sm">No sports skills tracked yet.</p>
                        <button onClick={() => openManualModuleRegistration('Personal', 'Sports')} className="mt-4 text-xs font-magic text-amber-400 hover:underline underline-offset-4">Register Athletic Module</button>
                      </div>
                    ) : (
                      getSortedSkills(user?.skills.filter(s => s.type === 'Personal' && s.personalSubCategory === 'Sports') || []).map(skill => (
                        <MagicCard key={skill.id} className="group cursor-pointer border-stone-800 hover:border-amber-400/50 bg-stone-900/40" onClick={() => handleOpenTrainerForSkill(skill)}>
                          <div className="flex justify-between items-start mb-4">
                            <h4 className="text-lg font-sans font-bold text-white block leading-tight">{skill.originalName}</h4>
                            <DifficultyBadge difficulty={skill.difficulty} />
                          </div>
                          <ProgressBar current={skill.experience} max={skill.maxExperience} color="#fbbf24" />
                          <div className="mt-4 flex justify-between items-center text-[9px] text-stone-500 uppercase">
                            <span>Lvl {skill.level} Stamina</span>
                            <span className="text-amber-400">Sports Module</span>
                          </div>
                        </MagicCard>
                      ))
                    )}
                  </div>
                </MagicCard>

                <div className="pt-6 flex justify-center">
                  <button onClick={() => { setChosenSector('Personal'); setRequestStep('description_entry'); setView('request'); }} className="px-10 py-5 bg-stone-900 border-2 border-stone-800 text-stone-400 hover:border-[#d6bc7e] hover:text-[#d6bc7e] transition-all font-magic rounded-full flex items-center gap-4 text-base shadow-2xl">
                    <BrainCircuit className="w-6 h-6" /> Sector Discovery Analysis
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {view === 'library' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
              <div className="flex items-center gap-3 overflow-x-auto pb-2 no-scrollbar lg:flex-1">
                <Filter className="w-4 h-4 text-stone-500 flex-shrink-0" />
                {libraryCategories.map(cat => (
                  <button key={cat} onClick={() => setSelectedLibraryCategory(cat)} className={`px-4 py-1.5 rounded-full border text-xs whitespace-nowrap transition-all font-magic ${selectedLibraryCategory === cat ? 'bg-[#d6bc7e] text-stone-900 border-[#d6bc7e]' : 'border-stone-800 text-stone-500 hover:border-stone-600'}`}>{cat}</button>
                ))}
              </div>
              <div className="relative w-full sm:w-64">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-500" />
                <input type="text" placeholder="Search skills..." value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full bg-stone-900/50 border border-stone-800 rounded-full py-2 pl-10 pr-4 text-sm focus:border-[#d6bc7e] outline-none" />
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {libraryCourses.filter(course => {
                const matchesCategory = selectedLibraryCategory === 'All Skills' || selectedLibraryCategory === course.category;
                const matchesSearch = searchTerm.trim() === '' || course.title.toLowerCase().includes(searchTerm.toLowerCase());
                return matchesCategory && matchesSearch;
              }).map((course, i) => (
                <MagicCard key={i} title={course.title} className={`cursor-pointer group hover:scale-[1.02] transition-transform ${course.type === 'Academic' ? 'border-blue-900/10' : 'border-pink-900/10'}`} onClick={() => handleOpenTrainerForSkill(course)}>
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-2">
                      <div className={course.type === 'Academic' ? 'text-blue-400' : 'text-pink-400'}>{course.icon}</div>
                      <span className={`text-[10px] font-magic uppercase tracking-widest ${course.type === 'Academic' ? 'text-blue-400' : 'text-pink-400'}`}>
                        {course.type === 'Academic' ? 'Academic' : 'Personal'}
                      </span>
                    </div>
                    <DifficultyBadge difficulty={course.difficulty} />
                  </div>
                  <p className="text-[10px] text-stone-500 italic mb-4">({course.originalName})</p>
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-2 text-[10px] text-stone-500 uppercase tracking-widest"><Clock className="w-3 h-3" /> {course.duration}</div>
                    <Info className="w-3 h-3 text-stone-700" />
                  </div>
                  <button className="w-full py-2 bg-stone-800 hover:bg-[#d6bc7e] hover:text-stone-900 transition-all rounded font-magic text-xs">Enroll Module</button>
                </MagicCard>
              ))}
            </div>
          </div>
        )}

        {view === 'request' && (
          <div className="max-w-4xl mx-auto py-8 animate-in fade-in duration-500">
            {requestStep === 'sector_selection' ? (
              <div className="space-y-8">
                <div className="text-center space-y-2">
                  <h3 className="text-3xl font-magic text-[#d6bc7e]">Sector Selection</h3>
                  <p className="text-stone-500 italic">Where does your new mastery belong?</p>
                </div>
                <SectorSelection 
                  activeSector={chosenSector}
                  onSelect={(s) => { setChosenSector(s); setRequestStep('description_entry'); }} 
                />
              </div>
            ) : (
              <div className="space-y-6">
                {!currentAnalysis ? (
                  <MagicCard 
                    title={`${chosenSector} Intake Assessment`} 
                    glowColor={chosenSector === 'Academic' ? '#60a5fa' : '#f472b6'}
                  >
                    <button 
                      onClick={() => setRequestStep('sector_selection')}
                      className="absolute top-6 right-6 text-stone-500 hover:text-white transition-colors"
                    >
                      <X className="w-5 h-5" />
                    </button>
                    <div className="flex items-start gap-4 mb-8">
                      <div className={`p-3 rounded-full border ${chosenSector === 'Academic' ? 'bg-blue-500/10 border-blue-900/30 text-blue-400' : 'bg-pink-500/10 border-pink-900/30 text-pink-400'}`}>
                        {chosenSector === 'Academic' ? <BrainCircuit className="w-6 h-6" /> : <Palette className="w-6 h-6" />}
                      </div>
                      <div>
                        <h4 className="text-lg font-magic text-stone-200">Specific Requirement</h4>
                        <p className="text-sm text-stone-500 italic">"Describe the specific {chosenSector?.toLowerCase()} skill you want to acquire. Provide details on your goal."</p>
                      </div>
                    </div>
                    <form onSubmit={analyzeInitialSkill} className="space-y-6">
                      <div className="space-y-2">
                        <label className={`text-xs uppercase tracking-widest font-magic ${chosenSector === 'Academic' ? 'text-blue-400' : 'text-pink-400'}`}>
                          Mastery Objective & Context
                        </label>
                        <textarea 
                          required 
                          value={skillRequestDesc} 
                          onChange={(e) => setSkillRequestDesc(e.target.value)} 
                          placeholder={`e.g. ${chosenSector === 'Academic' ? 'I want to master Deep Learning to advance my career in Data Science...' : 'I want to learn Jazz Piano to perform at local venues...'}`} 
                          className="w-full min-h-[180px] bg-stone-900/50 border border-stone-800 rounded-xl p-6 text-sm outline-none transition-all resize-none text-stone-300 shadow-inner focus:border-[#d6bc7e]" 
                        />
                      </div>
                      <button 
                        type="submit" 
                        disabled={loading || !skillRequestDesc.trim()} 
                        className={`w-full py-4 font-magic rounded-xl hover:scale-[1.02] transition-all disabled:opacity-50 shadow-lg ${chosenSector === 'Academic' ? 'bg-blue-400 text-stone-900' : 'bg-pink-400 text-stone-900'}`}
                      >
                        {loading ? 'Consulting the Archives...' : 'Generate Sector Impact Report'}
                      </button>
                    </form>
                  </MagicCard>
                ) : (
                  <MagicCard title="Classification Report" glowColor={currentAnalysis.type === 'Academic' ? '#60a5fa' : '#f472b6'}>
                    <div className="py-2 space-y-8 animate-in zoom-in-95 duration-500">
                      <div className="flex flex-col md:flex-row items-center gap-8 border-b border-stone-800 pb-8">
                        <div className={`w-24 h-24 rounded-full flex items-center justify-center border-2 ${currentAnalysis.type === 'Academic' ? 'border-blue-500 bg-blue-500/10' : 'border-pink-500 bg-pink-500/10'}`}>
                          {currentAnalysis.type === 'Academic' ? <Briefcase className="w-12 h-12 text-blue-400" /> : <Smile className="w-12 h-12 text-pink-400" />}
                        </div>
                        <div className="text-center md:text-left">
                          <h4 className="text-3xl font-magic text-white mb-1">{currentAnalysis.aiSkillName}</h4>
                          <p className={`text-xs uppercase tracking-[0.2em] font-magic ${currentAnalysis.type === 'Academic' ? 'text-blue-400' : 'text-pink-400'}`}>{currentAnalysis.type} Sector Verified</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-3">
                          <h5 className="text-xs uppercase tracking-widest text-stone-500 font-magic flex items-center gap-2"><Info className="w-3 h-3" /> Categorization Insight</h5>
                          <p className="text-sm text-stone-300 italic leading-relaxed bg-stone-900/50 p-4 rounded-lg border border-stone-800">"{currentAnalysis.reasoning}"</p>
                        </div>
                        <div className="space-y-3">
                          <h5 className="text-xs uppercase tracking-widest text-stone-500 font-magic flex items-center gap-2"><Star className="w-3 h-3" /> Development Potential</h5>
                          <p className="text-sm text-stone-300 leading-relaxed bg-stone-900/50 p-4 rounded-lg border border-stone-800">{currentAnalysis.analysis}</p>
                        </div>
                      </div>
                      <div className="flex flex-col sm:flex-row gap-4 pt-4">
                        <button onClick={approveSkillRequest} disabled={loading} className={`flex-1 py-4 font-magic rounded-xl hover:brightness-110 transition-all shadow-lg ${currentAnalysis.type === 'Academic' ? 'bg-blue-400 text-stone-900' : 'bg-pink-400 text-stone-900'}`}>
                          {loading ? 'Adding...' : 'Accept and Add to Sector Plan'}
                        </button>
                        <button onClick={() => { setSkillRequestDesc(''); setCurrentAnalysis(null); }} className="px-8 py-4 bg-stone-900 text-stone-400 border border-stone-800 font-magic rounded-xl hover:bg-stone-800 transition-all">New Mastery</button>
                      </div>
                    </div>
                  </MagicCard>
                )}
              </div>
            )}
          </div>
        )}

        {view === 'mentor' && (
          <div className="max-w-4xl mx-auto h-[calc(100vh-250px)] md:h-[calc(100vh-200px)] flex flex-col animate-in fade-in duration-500">
            <div className="mb-4 flex items-center justify-between gap-4">
              <div className="flex gap-4 overflow-x-auto pb-2 no-scrollbar">
                {['Minerva', 'Filius', 'Pomona', 'Sybill', 'Albus'].map(prof => (
                  <button key={prof} onClick={() => { setActiveProfessor(prof); }} className={`px-4 py-2 rounded-full border whitespace-nowrap transition-all font-magic text-xs ${activeProfessor === prof ? 'bg-[#d6bc7e] text-stone-900 border-[#d6bc7e]' : 'border-stone-800 text-stone-500 hover:border-stone-600'}`}>{prof}</button>
                ))}
              </div>
              <button 
                onClick={clearChat}
                disabled={currentMentorChat.length === 0}
                className="p-2 text-stone-500 hover:text-red-500 transition-colors disabled:opacity-0"
                title="Clear Conversation"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
            <MagicCard className="flex-1 flex flex-col p-0 overflow-hidden">
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {currentMentorChat.length === 0 && (
                  <div className="text-center py-20 text-stone-600 italic">
                    "Select a mentor and ask for guidance on your mastery journey. Your progress and history are preserved."
                  </div>
                )}
                {currentMentorChat.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-4 rounded-2xl text-sm ${msg.role === 'user' ? 'bg-[#d6bc7e] text-stone-900 rounded-tr-none' : 'bg-stone-900 border border-stone-800 rounded-tl-none text-stone-300'}`}>{msg.content}</div>
                  </div>
                ))}
                <div ref={chatEndRef} />
              </div>
              <div className="p-4 bg-stone-900/50 border-t border-stone-800 flex gap-4">
                <input 
                  value={userInput} 
                  onChange={(e) => setUserInput(e.target.value)} 
                  onKeyDown={(e) => e.key === 'Enter' && handleChat()} 
                  disabled={loading}
                  placeholder={`Ask Mentor ${activeProfessor} for advice...`} 
                  className="flex-1 bg-stone-800 border border-stone-700 rounded-lg px-4 py-2 text-sm focus:outline-none focus:border-[#d6bc7e] text-stone-200 disabled:opacity-50" 
                />
                <button 
                  onClick={handleChat} 
                  disabled={loading || !userInput.trim()}
                  className="p-2 bg-[#d6bc7e] text-stone-900 rounded-lg hover:scale-105 transition-transform disabled:opacity-50"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
            </MagicCard>
          </div>
        )}

        {/* Manual Module Creation Modal */}
        <Modal 
          isOpen={isManualModuleOpen} 
          onClose={() => setIsManualModuleOpen(false)} 
          title={`${manualModule.sector} Mastery Entry`}
        >
          <form onSubmit={handleAddManualModule} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest text-[#d6bc7e] font-magic">Module Name</label>
              <input 
                required 
                value={manualModule.name} 
                onChange={e => setManualModule({...manualModule, name: e.target.value})} 
                className="w-full bg-stone-900/50 border border-stone-800 rounded-lg py-3 px-4 outline-none focus:border-[#d6bc7e] text-stone-200" 
                placeholder={`e.g. ${manualModule.subCategory === 'Sports' ? 'High Performance Swimming' : manualModule.subCategory === 'Life Skills' ? 'Modern Culinary Arts' : 'Quantum Computing'}`} 
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest text-[#d6bc7e] font-magic">Category</label>
              <div className="p-3 bg-stone-900 border border-stone-800 rounded-xl text-stone-400 text-sm font-magic flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${manualModule.sector === 'Academic' ? 'bg-blue-400' : 'bg-pink-400'}`}></span> {manualModule.subCategory}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest text-[#d6bc7e] font-magic">Curriculum (Description)</label>
              <textarea 
                required 
                value={manualModule.description} 
                onChange={e => setManualModule({...manualModule, description: e.target.value})} 
                className="w-full min-h-[100px] bg-stone-900/50 border border-stone-800 rounded-lg py-3 px-4 outline-none focus:border-[#d6bc7e] text-stone-200 resize-none text-sm" 
                placeholder="What specific skills or goals will be mastered in this module?" 
              />
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest text-[#d6bc7e] font-magic">Rigor (Difficulty)</label>
                <div className="relative">
                  <Settings2 className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-500" />
                  <select 
                    value={manualModule.difficulty}
                    onChange={e => setManualModule({...manualModule, difficulty: e.target.value as Difficulty})}
                    className="w-full bg-stone-900 border border-stone-800 rounded-lg py-2.5 pl-10 pr-3 text-sm focus:border-[#d6bc7e] outline-none appearance-none text-stone-300"
                  >
                    <option value="Easy">Beginner (Easy)</option>
                    <option value="Medium">Intermediate (Medium)</option>
                    <option value="Hard">Advanced (Hard)</option>
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest text-[#d6bc7e] font-magic">Relevant Mentor</label>
                <div className="relative">
                  <GraduationCap className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-500" />
                  <select 
                    value={manualModule.mentor}
                    onChange={e => setManualModule({...manualModule, mentor: e.target.value})}
                    className="w-full bg-stone-900 border border-stone-800 rounded-lg py-2.5 pl-10 pr-3 text-sm focus:border-[#d6bc7e] outline-none appearance-none text-stone-300"
                  >
                    {Object.keys(trainerData).map(key => (
                      <option key={key} value={key}>{trainerData[key].name}</option>
                    ))}
                  </select>
                </div>
              </div>
            </div>

            <button type="submit" className="w-full py-4 bg-[#d6bc7e] text-[#0c0a09] font-magic rounded-xl hover:scale-[1.02] transition-all flex items-center justify-center gap-3 shadow-lg mt-2">
              <CheckCircle2 className="w-5 h-5" /> Finalize Module Entry
            </button>
          </form>
        </Modal>

        <Modal isOpen={isTrainerModalOpen} onClose={() => setIsTrainerModalOpen(false)} title="Lead Mentor Profile">
          {selectedTrainer && (
            <div className="flex flex-col items-center text-center space-y-6">
              <div className="w-32 h-32 rounded-full overflow-hidden border-2 border-[#d6bc7e] shadow-[0_0_20px_rgba(214,188,126,0.3)]"><img src={selectedTrainer.image} alt={selectedTrainer.name} className="w-full h-full object-cover" /></div>
              <div className="space-y-2">
                <h4 className="text-2xl font-magic text-white">{selectedTrainer.name}</h4>
                <p className="text-xs uppercase tracking-widest text-[#d6bc7e] font-magic">{selectedTrainer.role}</p>
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#d6bc7e]/10 border border-[#d6bc7e]/30 rounded-full"><GraduationCap className="w-3 h-3 text-[#d6bc7e]" /><span className="text-[10px] text-stone-300 uppercase tracking-tighter">Specialty: {selectedTrainer.specialty}</span></div>
              </div>
              <p className="text-sm text-stone-400 italic leading-relaxed px-4">"{selectedTrainer.bio}"</p>
              <button onClick={() => { 
                const profKey = selectedTrainer.name.split(' ').pop() || 'Albus';
                setActiveProfessor(profKey); 
                setView('mentor'); 
                setIsTrainerModalOpen(false); 
              }} className="w-full py-3 bg-[#d6bc7e] text-[#0c0a09] font-magic rounded-xl hover:brightness-110 transition-all flex items-center justify-center gap-2"><MessageCircle className="w-5 h-5" /> Consult Mentor</button>
            </div>
          )}
        </Modal>

        <Modal isOpen={!!selectedArchiveRequest} onClose={() => setSelectedArchiveRequest(null)} title="Archived Classification Report">
          {selectedArchiveRequest && (
            <div className="space-y-6">
              <div className="flex items-center gap-4 border-b border-stone-800 pb-4">
                <div className={`p-3 rounded-xl ${selectedArchiveRequest.type === 'Academic' ? 'bg-blue-500/10 text-blue-400' : 'bg-pink-500/10 text-pink-400'}`}>
                  {selectedArchiveRequest.type === 'Academic' ? <Briefcase className="w-6 h-6" /> : <Smile className="w-6 h-6" />}
                </div>
                <div>
                  <h4 className="text-xl font-magic text-white">{selectedArchiveRequest.aiSkillName}</h4>
                  <p className="text-xs text-stone-500 uppercase tracking-widest">{selectedArchiveRequest.type} Sector</p>
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-magic text-[#d6bc7e] uppercase tracking-widest block mb-1">Original Goal</label>
                  <p className="text-sm text-stone-300 italic">"{selectedArchiveRequest.originalDescription}"</p>
                </div>
                <div>
                  <label className="text-[10px] font-magic text-[#d6bc7e] uppercase tracking-widest block mb-1">AI Reasoning</label>
                  <p className="text-sm text-stone-300 leading-relaxed bg-stone-900/50 p-3 rounded border border-stone-800">{selectedArchiveRequest.reasoning}</p>
                </div>
                <div>
                  <label className="text-[10px] font-magic text-[#d6bc7e] uppercase tracking-widest block mb-1">Impact Analysis</label>
                  <p className="text-sm text-stone-300 leading-relaxed bg-stone-900/50 p-3 rounded border border-stone-800">{selectedArchiveRequest.analysis}</p>
                </div>
              </div>
              <div className="pt-4 flex justify-between items-center text-[10px] text-stone-500 uppercase tracking-tighter">
                <span>Record ID: {selectedArchiveRequest.id}</span>
                <span>Date: {selectedArchiveRequest.requestDate}</span>
              </div>
            </div>
          )}
        </Modal>

        <div className="flex justify-center gap-6 mt-12 py-8 border-t border-stone-800">
          <button onClick={handlePrevView} className="px-8 py-3 rounded-full border border-stone-800 text-stone-500 hover:text-[#d6bc7e] transition-all bg-stone-900/50 font-magic text-sm flex items-center gap-3 shadow-lg"><ArrowLeft className="w-5 h-5" /> Previous</button>
          <button onClick={handleNextView} className="px-8 py-3 rounded-full border border-stone-800 text-stone-500 hover:text-[#d6bc7e] transition-all bg-stone-900/50 font-magic text-sm flex items-center gap-3 shadow-lg">Next <ArrowRight className="w-5 h-5" /></button>
        </div>
      </main>
    </div>
  );
};

export default App;
