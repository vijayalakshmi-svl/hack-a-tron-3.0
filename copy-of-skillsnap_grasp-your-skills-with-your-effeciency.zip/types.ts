
export enum House {
  Gryffindor = 'Gryffindor',
  Slytherin = 'Slytherin',
  Ravenclaw = 'Ravenclaw',
  Hufflepuff = 'Hufflepuff'
}

export type Difficulty = 'Easy' | 'Medium' | 'Hard';

export interface Trainer {
  name: string;
  role: string;
  bio: string;
  image: string;
  specialty: string;
}

export interface SkillRequest {
  id: string;
  originalDescription: string;
  aiSkillName: string;
  type: 'Academic' | 'Personal';
  status: 'Pending Review' | 'Processing' | 'Approved';
  requestDate: string;
  reasoning?: string;
  analysis?: string;
}

export interface Skill {
  id: string;
  name: string;
  originalName: string; // The real-world equivalent name
  level: number;
  experience: number;
  maxExperience: number;
  category: string;
  description: string;
  difficulty: Difficulty;
  type: 'Academic' | 'Personal';
  academicSubCategory?: 'Technical' | 'Theoretical';
  personalSubCategory?: 'Life Skills' | 'Sports';
}

export interface UserProfile {
  name: string;
  email: string;
  password?: string; // Added for security
  house: House | null;
  level: number;
  xp: number;
  housePoints: number;
  skills: Skill[];
  interests: string[];
  requests: SkillRequest[];
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  rewardXP: number;
  rewardPoints: number;
  status: 'Available' | 'Active' | 'Completed';
}

export interface ChatMessage {
  role: 'user' | 'model';
  parts: { text: string }[];
}
