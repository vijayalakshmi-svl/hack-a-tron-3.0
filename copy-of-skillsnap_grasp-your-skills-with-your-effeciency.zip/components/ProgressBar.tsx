
import React from 'react';

interface ProgressBarProps {
  current: number;
  max: number;
  color?: string;
  label?: string;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ current, max, color = '#d6bc7e', label }) => {
  const percentage = Math.min(100, (current / max) * 100);
  
  return (
    <div className="w-full">
      {label && <div className="flex justify-between text-xs mb-1 text-stone-400 font-magic uppercase tracking-widest">{label} <span>{Math.round(percentage)}%</span></div>}
      <div className="h-2 bg-stone-900 rounded-full overflow-hidden border border-stone-800">
        <div 
          className="h-full transition-all duration-1000 ease-out relative"
          style={{ 
            width: `${percentage}%`, 
            backgroundColor: color,
            boxShadow: `0 0 8px ${color}`
          }}
        >
          <div className="absolute inset-0 bg-white/20 animate-pulse" />
        </div>
      </div>
    </div>
  );
};

export default ProgressBar;
