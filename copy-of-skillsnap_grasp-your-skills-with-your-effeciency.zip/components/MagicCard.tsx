
import React from 'react';

interface MagicCardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  glowColor?: string;
  // Added onClick prop to support interactivity for cards in the dashboard and library
  onClick?: () => void;
}

const MagicCard: React.FC<MagicCardProps> = ({ 
  children, 
  className = '', 
  title, 
  glowColor = 'rgba(214, 188, 126, 0.2)',
  onClick 
}) => {
  return (
    <div 
      className={`relative group bg-[#1c1917] border border-[#44403c] rounded-xl p-6 transition-all duration-500 hover:border-[#d6bc7e] ${className}`}
      style={{ boxShadow: `0 0 20px -10px ${glowColor}` }}
      // Fixed: Support for the onClick handler used in App.tsx
      onClick={onClick}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-[#d6bc7e10] to-transparent opacity-0 group-hover:opacity-100 transition-opacity rounded-xl pointer-events-none" />
      {title && (
        <h3 className="text-xl font-magic text-[#d6bc7e] mb-4 border-b border-[#44403c] pb-2">
          {title}
        </h3>
      )}
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
};

export default MagicCard;
